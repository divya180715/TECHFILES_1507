"""
================================================================================
  COMPLETE DATA PREPROCESSING PIPELINE IN DATA MINING
  Author  : ML Engineering Team
  Version : 1.0
  Dataset : Synthetic HR / Employee Attrition Dataset
================================================================================

This module covers ALL major preprocessing steps:
  1.  Data Collection / Import
  2.  Exploratory Data Analysis (EDA)
  3.  Handling Missing Values
  4.  Handling Duplicate Data
  5.  Data Cleaning
  6.  Handling Outliers (IQR + Z-score)
  7.  Data Transformation (Normalization & Standardization)
  8.  Encoding Categorical Data (Label + One-Hot)
  9.  Feature Engineering
  10. Feature Selection (Correlation + Importance)
  11. Data Integration
  12. Data Reduction (PCA)
  13. Train / Test Split
  14. Bonus: Logistic Regression Model
================================================================================
"""

# ─────────────────────────────────────────────────────────────────────────────
# 0. IMPORTS
# ─────────────────────────────────────────────────────────────────────────────
import os
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")          # non-interactive backend – safe for scripts
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from scipy import stats
from sklearn.preprocessing import (
    MinMaxScaler, StandardScaler, LabelEncoder
)
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    classification_report, confusion_matrix, accuracy_score
)
from sklearn.impute import SimpleImputer

warnings.filterwarnings("ignore")

# ── output directory ──────────────────────────────────────────────────────────
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# HELPER: save figure
# ─────────────────────────────────────────────────────────────────────────────
def save_fig(name: str) -> None:
    path = os.path.join(OUTPUT_DIR, name)
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   ✅  Saved → {path}")


# ─────────────────────────────────────────────────────────────────────────────
# STEP 1 – DATA COLLECTION / DATASET GENERATION
# ─────────────────────────────────────────────────────────────────────────────
def step1_generate_dataset(n: int = 500, seed: int = 42) -> pd.DataFrame:
    """
    Generate a realistic synthetic HR / Employee-Attrition dataset.
    Intentionally adds:
      • missing values  (NaN)
      • duplicate rows
      • outliers
      • inconsistent categorical labels
      • irrelevant columns
    so every preprocessing technique has real work to do.
    """
    print("\n" + "="*70)
    print("  STEP 1 – DATA COLLECTION / IMPORTING DATASET")
    print("="*70)

    rng = np.random.default_rng(seed)

    departments   = ["Sales", "IT", "HR", "Finance", "Operations"]
    education_lvl = ["Bachelor", "Master", "PhD", "HighSchool"]
    gender_vals   = ["Male", "Female"]
    job_roles     = ["Analyst", "Manager", "Director", "Engineer", "Clerk"]

    age          = rng.integers(22, 60, n).astype(float)
    experience   = np.clip(age - 22 + rng.integers(-3, 3, n), 0, None).astype(float)
    salary       = (30_000 + experience * 2_500 + rng.normal(0, 5_000, n)).round(2)
    satisfaction = rng.integers(1, 6, n).astype(float)          # 1–5 scale
    hours_week   = rng.integers(30, 70, n).astype(float)
    dept         = rng.choice(departments, n)
    edu          = rng.choice(education_lvl, n)
    gender       = rng.choice(gender_vals, n)
    job_role     = rng.choice(job_roles, n)
    attrition    = (salary < 40_000).astype(int) | rng.integers(0, 2, n)
    attrition    = np.clip(attrition, 0, 1)

    df = pd.DataFrame({
        "EmployeeID"     : range(1, n + 1),          # irrelevant column
        "Age"            : age,
        "Gender"         : gender,
        "Department"     : dept,
        "Education"      : edu,
        "JobRole"        : job_role,
        "YearsExperience": experience,
        "MonthlySalary"  : salary,
        "SatisfactionScore": satisfaction,
        "HoursPerWeek"   : hours_week,
        "Attrition"      : attrition,
    })

    # ── inject missing values (~8 %) ─────────────────────────────────────────
    for col in ["Age", "MonthlySalary", "SatisfactionScore", "Education"]:
        mask = rng.random(n) < 0.08
        df.loc[mask, col] = np.nan

    # ── inject duplicate rows ────────────────────────────────────────────────
    dup_rows = df.sample(15, random_state=seed)
    df = pd.concat([df, dup_rows], ignore_index=True)

    # ── inject outliers ───────────────────────────────────────────────────────
    df.loc[0, "MonthlySalary"]  = 500_000   # extreme salary
    df.loc[1, "HoursPerWeek"]   = 120       # impossible hours
    df.loc[2, "Age"]            = -5        # impossible age

    # ── inconsistent labels ───────────────────────────────────────────────────
    df.loc[rng.integers(0, n, 10), "Department"] = "sales"   # lowercase
    df.loc[rng.integers(0, n, 10), "Gender"]     = "male"

    # ── dummy "random noise" column (irrelevant) ─────────────────────────────
    df["RandomNoise"] = rng.random(len(df))

    print(f"   Dataset shape : {df.shape}")
    print(f"   Columns       : {list(df.columns)}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 2 – EXPLORATORY DATA ANALYSIS (EDA)
# ─────────────────────────────────────────────────────────────────────────────
def step2_eda(df: pd.DataFrame) -> None:
    print("\n" + "="*70)
    print("  STEP 2 – EXPLORATORY DATA ANALYSIS (EDA)")
    print("="*70)

    print("\n── head() ──────────────────────────────────────────────────────────")
    print(df.head())

    print("\n── info() ──────────────────────────────────────────────────────────")
    df.info()

    print("\n── describe() ─────────────────────────────────────────────────────")
    print(df.describe(include="all").T.to_string())

    print("\n── Data Types ──────────────────────────────────────────────────────")
    print(df.dtypes)

    print("\n── Missing Values ──────────────────────────────────────────────────")
    miss = df.isnull().sum()
    print(miss[miss > 0])

    # ── histograms ────────────────────────────────────────────────────────────
    num_cols = df.select_dtypes(include=np.number).columns.tolist()
    fig, axes = plt.subplots(3, 3, figsize=(15, 10))
    fig.suptitle("Step 2 – Feature Distributions (Before Preprocessing)",
                 fontsize=14, fontweight="bold")
    for ax, col in zip(axes.flat, num_cols[:9]):
        ax.hist(df[col].dropna(), bins=30, color="#4C72B0", edgecolor="white", alpha=0.85)
        ax.set_title(col, fontsize=10)
        ax.set_xlabel("Value"); ax.set_ylabel("Frequency")
    for ax in axes.flat[len(num_cols[:9]):]:
        ax.set_visible(False)
    plt.tight_layout()
    save_fig("step2_histograms.png")

    # ── class balance bar ─────────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(5, 4))
    df["Attrition"].value_counts().plot(kind="bar", color=["#4C72B0","#DD8452"],
                                        edgecolor="white", ax=ax)
    ax.set_title("Target Variable – Attrition Balance", fontweight="bold")
    ax.set_xlabel("Attrition (0=No, 1=Yes)"); ax.set_ylabel("Count")
    ax.tick_params(axis="x", rotation=0)
    plt.tight_layout()
    save_fig("step2_class_balance.png")

    print("\n   ✅  EDA complete – histograms & class balance plots saved.")


# ─────────────────────────────────────────────────────────────────────────────
# STEP 3 – HANDLING MISSING VALUES
# ─────────────────────────────────────────────────────────────────────────────
def step3_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "="*70)
    print("  STEP 3 – HANDLING MISSING VALUES")
    print("="*70)

    before = df.isnull().sum().sum()
    print(f"   Total missing before : {before}")

    # Numeric → median imputation
    num_cols = df.select_dtypes(include=np.number).columns.tolist()
    for col in num_cols:
        if df[col].isnull().any():
            median_val = df[col].median()
            df[col].fillna(median_val, inplace=True)
            print(f"   Numeric  '{col}' → filled with median ({median_val:.2f})")

    # Categorical → mode imputation
    cat_cols = df.select_dtypes(include="object").columns.tolist()
    for col in cat_cols:
        if df[col].isnull().any():
            mode_val = df[col].mode()[0]
            df[col].fillna(mode_val, inplace=True)
            print(f"   Category '{col}' → filled with mode  ({mode_val})")

    after = df.isnull().sum().sum()
    print(f"   Total missing after  : {after}")

    # Missing-value heatmap
    fig, ax = plt.subplots(figsize=(10, 4))
    miss_pct = (df.isnull().sum() / len(df) * 100).sort_values(ascending=False)
    miss_pct[miss_pct > 0].plot(kind="bar", color="#DD8452", edgecolor="white", ax=ax)
    ax.set_title("Missing Value % per Column (After Imputation = 0%)", fontweight="bold")
    ax.set_ylabel("Missing %")
    plt.tight_layout()
    save_fig("step3_missing_values.png")

    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 4 – HANDLING DUPLICATE DATA
# ─────────────────────────────────────────────────────────────────────────────
def step4_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "="*70)
    print("  STEP 4 – HANDLING DUPLICATE DATA")
    print("="*70)

    before = len(df)
    dups   = df.duplicated().sum()
    print(f"   Rows before      : {before}")
    print(f"   Duplicate rows   : {dups}")
    df.drop_duplicates(inplace=True)
    df.reset_index(drop=True, inplace=True)
    print(f"   Rows after drop  : {len(df)}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 5 – DATA CLEANING
# ─────────────────────────────────────────────────────────────────────────────
def step5_cleaning(df: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "="*70)
    print("  STEP 5 – DATA CLEANING")
    print("="*70)

    # Remove irrelevant columns
    drop_cols = ["EmployeeID", "RandomNoise"]
    df.drop(columns=[c for c in drop_cols if c in df.columns], inplace=True)
    print(f"   Dropped irrelevant columns : {drop_cols}")

    # Fix inconsistent casing in categorical columns
    for col in ["Department", "Gender", "Education", "JobRole"]:
        df[col] = df[col].str.strip().str.title()
        print(f"   Standardised casing → '{col}'")

    print(f"   Shape after cleaning : {df.shape}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 6 – HANDLING OUTLIERS
# ─────────────────────────────────────────────────────────────────────────────
def step6_outliers(df: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "="*70)
    print("  STEP 6 – HANDLING OUTLIERS")
    print("="*70)

    num_cols = ["Age", "MonthlySalary", "HoursPerWeek", "YearsExperience"]

    # ── boxplots BEFORE ───────────────────────────────────────────────────────
    fig, axes = plt.subplots(1, len(num_cols), figsize=(16, 5))
    fig.suptitle("Step 6 – Boxplots BEFORE Outlier Removal", fontsize=13, fontweight="bold")
    for ax, col in zip(axes, num_cols):
        ax.boxplot(df[col].dropna(), patch_artist=True,
                   boxprops=dict(facecolor="#4C72B0", color="navy"),
                   medianprops=dict(color="white", linewidth=2))
        ax.set_title(col); ax.set_xlabel(col)
    plt.tight_layout(); save_fig("step6_boxplot_before.png")

    # ── IQR method ────────────────────────────────────────────────────────────
    print("\n   ── IQR Method ──")
    for col in num_cols:
        Q1  = df[col].quantile(0.25)
        Q3  = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lo, hi = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
        out_mask = (df[col] < lo) | (df[col] > hi)
        print(f"   {col:20s} | Q1={Q1:.1f} Q3={Q3:.1f} IQR={IQR:.1f}"
              f" | bounds=[{lo:.1f}, {hi:.1f}] | outliers={out_mask.sum()}")
        df[col] = df[col].clip(lower=lo, upper=hi)   # cap (Winsorize)

    # ── Z-score method (informational) ───────────────────────────────────────
    print("\n   ── Z-score Method (|z|>3 flagged) ──")
    for col in num_cols:
        z_scores = np.abs(stats.zscore(df[col].dropna()))
        print(f"   {col:20s} | values with |z|>3 : {(z_scores > 3).sum()}")

    # ── boxplots AFTER ────────────────────────────────────────────────────────
    fig, axes = plt.subplots(1, len(num_cols), figsize=(16, 5))
    fig.suptitle("Step 6 – Boxplots AFTER Outlier Removal (Winsorized)",
                 fontsize=13, fontweight="bold")
    for ax, col in zip(axes, num_cols):
        ax.boxplot(df[col].dropna(), patch_artist=True,
                   boxprops=dict(facecolor="#55A868", color="darkgreen"),
                   medianprops=dict(color="white", linewidth=2))
        ax.set_title(col); ax.set_xlabel(col)
    plt.tight_layout(); save_fig("step6_boxplot_after.png")

    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 7 – DATA TRANSFORMATION
# ─────────────────────────────────────────────────────────────────────────────
def step7_transformation(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Returns (df_minmax, df_standard) for demonstration; pipeline continues with standard."""
    print("\n" + "="*70)
    print("  STEP 7 – DATA TRANSFORMATION (Normalisation & Standardisation)")
    print("="*70)

    num_cols = ["Age", "MonthlySalary", "HoursPerWeek",
                "YearsExperience", "SatisfactionScore"]

    df_minmax   = df.copy()
    df_standard = df.copy()

    scaler_mm = MinMaxScaler()
    scaler_st = StandardScaler()

    df_minmax[num_cols]   = scaler_mm.fit_transform(df[num_cols])
    df_standard[num_cols] = scaler_st.fit_transform(df[num_cols])

    print("   Min-Max (0–1) stats:")
    print(df_minmax[num_cols].describe().loc[["min","max"]].round(4).to_string())
    print("\n   Standard (mean≈0, std≈1) stats:")
    print(df_standard[num_cols].describe().loc[["mean","std"]].round(4).to_string())

    # ── comparison plot ───────────────────────────────────────────────────────
    fig, axes = plt.subplots(2, len(num_cols), figsize=(18, 7))
    fig.suptitle("Step 7 – Normalisation vs Standardisation", fontsize=13, fontweight="bold")
    for i, col in enumerate(num_cols):
        axes[0, i].hist(df_minmax[col], bins=25, color="#4C72B0",
                        edgecolor="white", alpha=0.85)
        axes[0, i].set_title(f"MinMax\n{col}", fontsize=9)
        axes[1, i].hist(df_standard[col], bins=25, color="#DD8452",
                        edgecolor="white", alpha=0.85)
        axes[1, i].set_title(f"Standard\n{col}", fontsize=9)
    plt.tight_layout(); save_fig("step7_transformation.png")

    return df_minmax, df_standard


# ─────────────────────────────────────────────────────────────────────────────
# STEP 8 – ENCODING CATEGORICAL DATA
# ─────────────────────────────────────────────────────────────────────────────
def step8_encoding(df: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "="*70)
    print("  STEP 8 – ENCODING CATEGORICAL DATA")
    print("="*70)

    df = df.copy()

    # Label Encoding → binary / ordinal columns
    le = LabelEncoder()
    df["Gender_Encoded"] = le.fit_transform(df["Gender"])
    print(f"   Label Encoded 'Gender'  : {dict(zip(le.classes_, le.transform(le.classes_)))}")

    edu_order = {"Highschool": 0, "Bachelor": 1, "Master": 2, "Phd": 3}
    df["Education_Encoded"] = df["Education"].map(edu_order).fillna(1).astype(int)
    print(f"   Ordinal Encoded 'Education' : {edu_order}")

    # One-Hot Encoding → nominal columns
    ohe_cols = ["Department", "JobRole"]
    df = pd.get_dummies(df, columns=ohe_cols, drop_first=True)
    print(f"   One-Hot Encoded columns : {ohe_cols}")
    print(f"   Shape after encoding    : {df.shape}")

    # Drop original string columns (replaced)
    df.drop(columns=["Gender", "Education"], errors="ignore", inplace=True)

    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 9 – FEATURE ENGINEERING
# ─────────────────────────────────────────────────────────────────────────────
def step9_feature_engineering(df: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "="*70)
    print("  STEP 9 – FEATURE ENGINEERING")
    print("="*70)

    df = df.copy()

    # Salary per year of experience
    df["SalaryPerExpYear"] = (
        df["MonthlySalary"] / (df["YearsExperience"] + 1)
    ).round(2)

    # Overtime flag (>45 hours/week)
    df["IsOvertime"] = (df["HoursPerWeek"] > 45).astype(int)

    # Age group bucket
    df["AgeBucket"] = pd.cut(
        df["Age"],
        bins=[0, 30, 40, 50, 100],
        labels=[0, 1, 2, 3]
    ).cat.add_categories(-1).fillna(-1).astype(int)

    print("   New features created:")
    print("     • SalaryPerExpYear  – salary efficiency ratio")
    print("     • IsOvertime        – binary flag if hours > 45")
    print("     • AgeBucket         – ordinal age group (0–3)")
    print(f"   Shape : {df.shape}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 10 – FEATURE SELECTION
# ─────────────────────────────────────────────────────────────────────────────
def step10_feature_selection(df: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "="*70)
    print("  STEP 10 – FEATURE SELECTION")
    print("="*70)

    df = df.copy()

    # Convert boolean columns (from get_dummies) to int
    bool_cols = df.select_dtypes(include="bool").columns
    df[bool_cols] = df[bool_cols].astype(int)

    num_df = df.select_dtypes(include=np.number)

    # ── Correlation heatmap ───────────────────────────────────────────────────
    corr = num_df.corr()
    fig, ax = plt.subplots(figsize=(14, 11))
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap="coolwarm",
                linewidths=0.4, ax=ax, annot_kws={"size": 7},
                vmin=-1, vmax=1, center=0,
                cbar_kws={"shrink": 0.8})
    ax.set_title("Step 10 – Correlation Heatmap", fontsize=14, fontweight="bold")
    plt.tight_layout(); save_fig("step10_correlation_heatmap.png")

    # ── Remove features with low correlation to target (<0.02) ──────────────
    target_corr = corr["Attrition"].abs().sort_values(ascending=False)
    print("\n   Correlation with Target (|corr| sorted):")
    print(target_corr.round(4).to_string())

    low_corr = target_corr[target_corr < 0.02].index.tolist()
    low_corr = [c for c in low_corr if c != "Attrition"]
    if low_corr:
        df.drop(columns=low_corr, inplace=True)
        print(f"\n   Dropped low-correlation features : {low_corr}")
    else:
        print("\n   No features dropped (all corr ≥ 0.02)")

    print(f"   Final shape after selection : {df.shape}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 11 – DATA INTEGRATION
# ─────────────────────────────────────────────────────────────────────────────
def step11_integration(df: pd.DataFrame) -> pd.DataFrame:
    print("\n" + "="*70)
    print("  STEP 11 – DATA INTEGRATION")
    print("="*70)

    # Simulate a second table (e.g. performance ratings from another source)
    np.random.seed(42)
    n = len(df)
    perf_df = pd.DataFrame({
        "PerformanceRating": np.random.choice([1, 2, 3, 4, 5], n),
        "TrainingHours"    : np.random.randint(0, 80, n),
    })

    df = pd.concat([df.reset_index(drop=True), perf_df], axis=1)
    print("   Integrated 'PerformanceRating' & 'TrainingHours' from secondary table.")
    print(f"   Shape after integration : {df.shape}")
    return df


# ─────────────────────────────────────────────────────────────────────────────
# STEP 12 – DATA REDUCTION (PCA)
# ─────────────────────────────────────────────────────────────────────────────
def step12_pca(df: pd.DataFrame) -> tuple[pd.DataFrame, np.ndarray]:
    print("\n" + "="*70)
    print("  STEP 12 – DATA REDUCTION (PCA)")
    print("="*70)

    # Convert any remaining bool columns
    bool_cols = df.select_dtypes(include="bool").columns
    df[bool_cols] = df[bool_cols].astype(int)

    X = df.drop(columns=["Attrition"]).select_dtypes(include=np.number)
    y = df["Attrition"].values

    # Fill any residual NaNs before PCA
    imputer = SimpleImputer(strategy="median")
    X = pd.DataFrame(imputer.fit_transform(X), columns=X.columns)

    # Standardise before PCA
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Fit PCA keeping enough components to explain ≥ 95 % variance
    pca_full = PCA()
    pca_full.fit(X_scaled)
    cum_var = np.cumsum(pca_full.explained_variance_ratio_)
    n_components = int(np.argmax(cum_var >= 0.95) + 1)
    print(f"   Components to explain 95% variance : {n_components} / {X.shape[1]}")

    pca = PCA(n_components=n_components)
    X_pca = pca.fit_transform(X_scaled)
    print(f"   X shape before PCA : {X_scaled.shape}")
    print(f"   X shape after  PCA : {X_pca.shape}")

    # ── Scree plot ─────────────────────────────────────────────────────────
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle("Step 12 – PCA Analysis", fontsize=13, fontweight="bold")

    axes[0].bar(range(1, len(pca_full.explained_variance_ratio_) + 1),
                pca_full.explained_variance_ratio_ * 100,
                color="#4C72B0", edgecolor="white")
    axes[0].set_xlabel("Principal Component")
    axes[0].set_ylabel("Variance Explained (%)")
    axes[0].set_title("Scree Plot")

    axes[1].plot(range(1, len(cum_var) + 1), cum_var * 100,
                 marker="o", color="#DD8452", linewidth=2, markersize=5)
    axes[1].axhline(95, color="red", linestyle="--", label="95% threshold")
    axes[1].axvline(n_components, color="green", linestyle="--",
                    label=f"n={n_components}")
    axes[1].set_xlabel("Number of Components")
    axes[1].set_ylabel("Cumulative Variance (%)")
    axes[1].set_title("Cumulative Variance Explained")
    axes[1].legend(); axes[1].grid(True, alpha=0.3)
    plt.tight_layout(); save_fig("step12_pca.png")

    # ── 2-D scatter with first 2 PCs ──────────────────────────────────────
    pca2 = PCA(n_components=2)
    X2   = pca2.fit_transform(X_scaled)
    fig, ax = plt.subplots(figsize=(8, 6))
    colors = ["#4C72B0", "#DD8452"]
    for cls, col in zip([0, 1], colors):
        mask = y == cls
        ax.scatter(X2[mask, 0], X2[mask, 1], c=col, label=f"Attrition={cls}",
                   alpha=0.6, s=30, edgecolors="none")
    ax.set_xlabel(f"PC1 ({pca2.explained_variance_ratio_[0]*100:.1f}%)")
    ax.set_ylabel(f"PC2 ({pca2.explained_variance_ratio_[1]*100:.1f}%)")
    ax.set_title("PCA 2-D Projection", fontweight="bold")
    ax.legend(); ax.grid(True, alpha=0.3)
    plt.tight_layout(); save_fig("step12_pca_scatter.png")

    return df, X_pca, y


# ─────────────────────────────────────────────────────────────────────────────
# STEP 13 – TRAIN / TEST SPLIT
# ─────────────────────────────────────────────────────────────────────────────
def step13_split(X: np.ndarray, y: np.ndarray):
    print("\n" + "="*70)
    print("  STEP 13 – TRAIN / TEST SPLIT")
    print("="*70)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"   Total samples  : {len(y)}")
    print(f"   Train samples  : {len(y_train)}  ({len(y_train)/len(y)*100:.0f}%)")
    print(f"   Test  samples  : {len(y_test)}   ({len(y_test)/len(y)*100:.0f}%)")
    print(f"   Train class distribution : {dict(zip(*np.unique(y_train, return_counts=True)))}")
    print(f"   Test  class distribution : {dict(zip(*np.unique(y_test, return_counts=True)))}")
    return X_train, X_test, y_train, y_test


# ─────────────────────────────────────────────────────────────────────────────
# BONUS – LOGISTIC REGRESSION MODEL
# ─────────────────────────────────────────────────────────────────────────────
def bonus_model(X_train, X_test, y_train, y_test) -> None:
    print("\n" + "="*70)
    print("  BONUS – LOGISTIC REGRESSION MODEL")
    print("="*70)

    model = LogisticRegression(max_iter=1000, random_state=42)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    acc = accuracy_score(y_test, y_pred)
    print(f"\n   Accuracy : {acc*100:.2f}%")
    print("\n   Classification Report:")
    print(classification_report(y_test, y_pred,
                                target_names=["No Attrition", "Attrition"]))

    # ── Confusion matrix heatmap ───────────────────────────────────────────
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                xticklabels=["Pred:No", "Pred:Yes"],
                yticklabels=["True:No", "True:Yes"])
    ax.set_title(f"Confusion Matrix  (Accuracy = {acc*100:.1f}%)", fontweight="bold")
    plt.tight_layout(); save_fig("bonus_confusion_matrix.png")

    print("   ✅  Model evaluation complete.")


# ─────────────────────────────────────────────────────────────────────────────
# ADDITIONAL: PAIRPLOT (after preprocessing – sample 200 rows for speed)
# ─────────────────────────────────────────────────────────────────────────────
def extra_pairplot(df_clean: pd.DataFrame) -> None:
    print("\n── Extra: Pairplot of key features ─────────────────────────────────")
    cols = ["Age", "MonthlySalary", "YearsExperience",
            "HoursPerWeek", "SatisfactionScore", "Attrition"]
    sample = df_clean[cols].dropna().sample(min(200, len(df_clean)), random_state=42)
    pg = sns.pairplot(sample, hue="Attrition", diag_kind="kde",
                      palette={0: "#4C72B0", 1: "#DD8452"}, height=2.0)
    pg.fig.suptitle("Pairplot – Key Features (Sampled 200 rows)",
                    y=1.02, fontsize=13, fontweight="bold")
    save_fig("extra_pairplot.png")


# ─────────────────────────────────────────────────────────────────────────────
# SAVE FINAL CLEANED DATASET
# ─────────────────────────────────────────────────────────────────────────────
def save_clean_dataset(df: pd.DataFrame) -> None:
    path = os.path.join(OUTPUT_DIR, "final_cleaned_dataset.csv")
    df.to_csv(path, index=False)
    print(f"\n   ✅  Final cleaned dataset → {path}")
    print(f"       Shape : {df.shape}")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────────────────────────────────────────
def main():
    print("\n" + "█"*70)
    print("  COMPLETE DATA PREPROCESSING PIPELINE IN DATA MINING")
    print("  Dataset : Synthetic HR Employee Attrition")
    print("█"*70)

    # Step 1 – Generate / Load
    df_raw = step1_generate_dataset()

    # Step 2 – EDA
    step2_eda(df_raw)
    df = df_raw.copy()

    # Step 3 – Missing values
    df = step3_missing_values(df)

    # Step 4 – Duplicates
    df = step4_duplicates(df)

    # Step 5 – Cleaning
    df = step5_cleaning(df)

    # Step 6 – Outliers
    df = step6_outliers(df)

    # Step 7 – Transformation (keep standardised version for modelling)
    df_mm, df_std = step7_transformation(df)

    # Step 8 – Encoding (on standardised df)
    df_enc = step8_encoding(df_std)

    # Step 9 – Feature Engineering
    df_eng = step9_feature_engineering(df_enc)

    # Step 10 – Feature Selection
    df_sel = step10_feature_selection(df_eng)

    # Step 11 – Integration
    df_int = step11_integration(df_sel)

    # Extra – Pairplot (on pre-encoded clean df for readability)
    extra_pairplot(df)

    # Step 12 – PCA
    df_final, X_pca, y = step12_pca(df_int)

    # Step 13 – Split
    X_train, X_test, y_train, y_test = step13_split(X_pca, y)

    # Bonus – Model
    bonus_model(X_train, X_test, y_train, y_test)

    # Save final dataset
    save_clean_dataset(df_int)

    print("\n" + "█"*70)
    print("  ALL PREPROCESSING STEPS COMPLETED SUCCESSFULLY!")
    print(f"  Outputs saved to : {os.path.abspath(OUTPUT_DIR)}")
    print("█"*70 + "\n")


if __name__ == "__main__":
    main()
